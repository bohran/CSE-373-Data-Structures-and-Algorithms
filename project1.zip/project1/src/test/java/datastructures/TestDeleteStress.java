package datastructures;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import datastructures.concrete.DoubleLinkedList;
import datastructures.interfaces.IList;

/**
 * This file should contain any tests that check and make sure your delete
 * method is efficient.
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestDeleteStress extends TestDoubleLinkedList {
    @Test(timeout = 15 * SECOND)
    public void testDeleteAllIsEfficient() {
        IList<Integer> list = new DoubleLinkedList<>();
        int cap = 5000000;
        for (int i = 0; i < cap; i++) {
            list.add(i);
        }

        for (int i = list.size() - 1; i >= 0; i--) {
            list.delete(i);
        }
        assertEquals(0, list.size());
    }

    @Test(timeout = 15 * SECOND)
    public void testDeleteEvenIsEfficient() {
        IList<Integer> list = new DoubleLinkedList<>();
        int cap = 100000;
        for (int i = 0; i < cap; i++) {
            list.add(i);
        }

        for (int i = list.size() - 1; i >= 0; i--) {
            if (i % 2 == 0) {
                list.delete(i);
            }
        }
        assertEquals(cap / 2, list.size());
    }

    @Test(timeout = 15 * SECOND)
    public void testDeleteOddIsEfficient() {
        IList<Integer> list = new DoubleLinkedList<>();
        int cap = 100000;
        for (int i = 0; i < cap; i++) {
            list.add(i);
        }

        for (int i = list.size() - 1; i >= 0; i--) {
            if (i % 2 != 0) {
                list.delete(i);
            }
        }
        assertEquals(cap / 2, list.size());
    }

    @Test(timeout = 15 * SECOND)
    public void testDeleteNearBeginningIsEfficient() {
        IList<Integer> list = new DoubleLinkedList<>();
        int cap = 5000000;
        for (int i = 0; i < cap; i++) {
            list.add(i);
        }

        for (int i = 0; i < cap / 2; i++) {
            list.delete(0);
        }
        assertEquals(cap / 2, list.size());
    }

    @Test(timeout = 15 * SECOND)
    public void testDeleteNearEndIsEfficient() {
        IList<Integer> list = new DoubleLinkedList<>();
        int cap = 5000000;
        for (int i = 0; i < cap; i++) {
            list.add(i);
        }

        for (int i = list.size() - 1; i >= cap / 2; i--) {
            list.delete(i);
        }
        assertEquals(cap / 2, list.size());
    }
}
