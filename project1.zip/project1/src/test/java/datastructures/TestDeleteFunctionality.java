package datastructures;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import datastructures.concrete.DoubleLinkedList;
import datastructures.interfaces.IList;
import static org.junit.Assert.fail;

/**
 * This class should contain all the tests you implement to verify that your
 * 'delete' method behaves as specified.
 *
 * This test _extends_ your TestDoubleLinkedList class. This means that when you
 * run this test, not only will your tests run, all of the ones in
 * TestDoubleLinkedList will also run.
 *
 * This also means that you can use any helper methods defined within
 * TestDoubleLinkedList here. In particular, you may find using the
 * 'assertListMatches' and 'makeBasicList' helper methods to be useful.
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestDeleteFunctionality extends TestDoubleLinkedList {

    @Test(timeout = SECOND)
    public void testDeleteFront() {
        IList<String> list = this.makeBasicList();
        assertEquals("a", list.delete(0));
        this.assertListMatches(new String[] {"b", "c" }, list);
    }

    @Test(timeout = SECOND)
    public void testDeleteMiddle() {
        IList<String> list = this.makeBasicList();
        assertEquals("b", list.delete(1));
        this.assertListMatches(new String[] {"a", "c" }, list);
    }

    @Test(timeout = SECOND)
    public void testDeleteEnd() {
        IList<String> list = this.makeBasicList();
        assertEquals("c", list.delete(2));
        this.assertListMatches(new String[] {"a", "b" }, list);
    }

    @Test(timeout = SECOND)
    public void testDeleteSingleElementList() {
        IList<String> list1 = new DoubleLinkedList<>();
        list1.insert(0, "a");
        list1.delete(0);
        this.assertListMatches(new String[] {}, list1);
    }

    @Test(timeout = SECOND)
    public void testDeleteOutOfBounds() {
        IList<String> list = this.makeBasicList();

        try {
            list.delete(-1);
            fail("Expected IndexOutOfBoundsException");
        } catch (IndexOutOfBoundsException ex) {
            System.out.println("You have passed in an invalid index");
        }

        try {
            list.delete(4);
            fail("Expected IndexOutOfBoundsException");
        } catch (IndexOutOfBoundsException ex) {
            System.out.println("You have passed in an invalid index");
        }
    }

    @Test(timeout = SECOND)
    public void testDeleteSizeUpdates() {
        IList<String> list = this.makeBasicList();
        int size = list.size();
        list.delete(1);
        assertEquals(size - 1, list.size());
    }

}
