package calculator;

import calculator.gui.MainWindow;

public class Main {
    public static void main(String[] args) {
        MainWindow.launch();
    }
}
