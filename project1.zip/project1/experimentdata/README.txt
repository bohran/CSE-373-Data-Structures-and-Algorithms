This folder will eventually contain the experimental data you'll
collect while working on your writeup.
