package datastructures.sorting;

import misc.BaseTest;
import misc.exceptions.EmptyContainerException;
import datastructures.concrete.ArrayHeap;
import datastructures.interfaces.IPriorityQueue;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

/**
 * See spec for details on what kinds of tests this class should include.
 */
public class TestArrayHeapFunctionality extends BaseTest {
    protected <T extends Comparable<T>> IPriorityQueue<T> makeInstance() {
        return new ArrayHeap<>();
    }
    
    protected IPriorityQueue<Integer> makeBasicArrayHeap(){
        IPriorityQueue<Integer> testHeap = this.makeInstance();
        for (int i = 0; i < 50; i++) {
            testHeap.insert(i);
        }
        return testHeap;
    }

    // given test
    @Test(timeout=SECOND)
    public void testBasicSize() {
        IPriorityQueue<Integer> heap = this.makeInstance();
        heap.insert(3);
        assertEquals(1, heap.size());
        assertTrue(!heap.isEmpty());
    }
    

    @Test(timeout=SECOND)
    public void testRemoveMin() {
        IPriorityQueue<Integer> heap = makeBasicArrayHeap();
        
        int ret= heap.removeMin();
        
        assertEquals(0, ret);
        assertEquals(49, heap.size());
    }
    
    @Test(timeout=SECOND)
    public void testPeekMin() {
        IPriorityQueue<Integer> testHeap = this.makeBasicArrayHeap();
        
        assertEquals(0, testHeap.peekMin());
        assertEquals(50, testHeap.size());
    }
    
    @Test(timeout=SECOND)
    public void testInsert() {
        IPriorityQueue<Integer> testHeap = this.makeBasicArrayHeap();
        
        testHeap.insert(-10);
        
        int ret = testHeap.peekMin();
        
        assertEquals(-10, ret);
        assertEquals(51, testHeap.size());
    } 

    @Test(timeout=SECOND)
    public void testSize() {
        IPriorityQueue<Integer> testHeap = this.makeBasicArrayHeap();
        
        assertEquals(50, testHeap.size());
    }
    
    @Test(timeout=SECOND) 
    public void testRemoveRepeatValues() {
        IPriorityQueue<Integer> testHeap = this.makeInstance();
        for (int i = 0; i < 10; i++) {
            testHeap.insert(5);
        }
        
        int ret = testHeap.removeMin();
        
        assertEquals(5, ret);
        assertEquals(9, testHeap.size());
    }
    
    @Test(timeout=SECOND)
    public void testRemoveMinForEmptyArrayHeap() {
        IPriorityQueue<Integer> testHeap = this.makeInstance();
        
        try {
            testHeap.removeMin();
            fail("Expected EmptyContainerException");
        } catch (EmptyContainerException ex) {
            // do nothing
        }
    }
    
    
    @Test(timeout=SECOND)
    public void testRemoveAllButOne() {
        IPriorityQueue<Integer> testHeap = this.makeBasicArrayHeap();
        
        for (int i = 0; i < 49; i++) {
            testHeap.removeMin();
        }
        
        assertEquals(49, testHeap.peekMin());
        assertEquals(1, testHeap.size());
    }    
    
    @Test(timeout=SECOND)
    public void testPeekMinWithRepeatValues() {
        IPriorityQueue<Integer> testHeap = this.makeInstance();
        for (int i = 0; i < 10; i++) {
            testHeap.insert(5);
        }
        
        int ret = testHeap.peekMin();
        
        assertEquals(5, ret);
        assertEquals(10, testHeap.size());
    }
    
    
    @Test(timeout=SECOND)
    public void testPeekMinForEmptyArrayHeap() {
        IPriorityQueue<Integer> testHeap = this.makeInstance();
        
        try {
            testHeap.peekMin();
            fail("Expected EmptyContainerException");
        } catch (EmptyContainerException ex) {
            // do nothing
        }
    }
    
    @Test(timeout=SECOND)
    public void testInsertNulls() {
        IPriorityQueue<Integer> testHeap = this.makeInstance();
        
        try {
            testHeap.insert(null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // do nothing
        }
    }
    
    @Test(timeout=SECOND) 
    public void testInsertRepeatValues() {
        IPriorityQueue<Integer> testHeap = this.makeInstance();
        for (int i = 0; i < 10; i++) {
            testHeap.insert(5);
        }
        
        assertEquals(5, testHeap.peekMin());
        assertEquals(10, testHeap.size());
    }
    
    @Test(timeout=SECOND)
    public void testInsertOnEmptyArrayHeap() {
        IPriorityQueue<Integer> testHeap = this.makeInstance();
        
        testHeap.insert(5);
        
        assertEquals(1, testHeap.size());
        assertEquals(5, testHeap.removeMin());
    }

    
    @Test(timeout=SECOND)
    public void testSizeForEmptyArrayHeap() {
        IPriorityQueue<Integer> testHeap = this.makeInstance();
        
        assertEquals(0, testHeap.size());
    }
    
    @Test(timeout=SECOND) 
    public void testInsertNewMinimumValue() {
        IPriorityQueue<Integer> testHeap = this.makeBasicArrayHeap();
        
        testHeap.insert(-1);
        
        assertEquals(-1, testHeap.peekMin());
        assertEquals(51, testHeap.size());
    }
    
    public void testInsertNewMaximumValue() {
        IPriorityQueue<Integer> testHeap = this.makeBasicArrayHeap();
        
        testHeap.insert(51);
        
        for (int i = 0; i < testHeap.size() - 1; i++) {
            testHeap.removeMin();
        }
        
        assertEquals(51, testHeap.peekMin());
        assertEquals(1, testHeap.size());
    }
    
    @Test(timeout=SECOND)
    public void preserveSortedOrderAfterRemove() {
        IPriorityQueue<Integer> testHeap = makeBasicArrayHeap();
        List<Integer> removedListVals = new ArrayList<>();
        
        while (testHeap.size() > 0) {
            removedListVals.add(testHeap.removeMin());
        }
        
        List<Integer> resultList = new ArrayList<>();
        
        for (int i = 0; i < 50; i++) {
            resultList.add(i);
        }
        
        assertEquals(resultList, removedListVals);
        assertEquals(0, testHeap.size());
    }
}
