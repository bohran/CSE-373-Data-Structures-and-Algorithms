package datastructures.sorting;

import misc.BaseTest;
import datastructures.concrete.DoubleLinkedList;
import datastructures.interfaces.IList;
import misc.Searcher;

import static org.junit.Assert.fail;

import org.junit.Test;

/**
 * See spec for details on what kinds of tests this class should include.
 */
public class TestTopKSortFunctionality extends BaseTest {
    
    protected IList<Integer> makeBasicList(){
        IList<Integer> thisList = new DoubleLinkedList<>();
        for (int i = 0; i < 50; i++) {
            thisList.add(i);
        }
        
        return thisList;
    }

    // given test
    @Test(timeout=SECOND)
    public void testSimpleUsage() {
        IList<Integer> list = new DoubleLinkedList<>();
        for (int i = 0; i < 20; i++) {
            list.add(i);
        }

        IList<Integer> top = Searcher.topKSort(5, list);
        assertEquals(5, top.size());
        for (int i = 0; i < top.size(); i++) {
            assertEquals(15 + i, top.get(i));
        }
    }
    
    @Test(timeout=SECOND)
    public void testTopZero() {
        IList<Integer> testList = makeBasicList();
        
        IList<Integer> topKList = Searcher.topKSort(0, testList);
        
        assertEquals(0, topKList.size());
    }
    
    @Test(timeout=SECOND)
    public void testListContainsFewerThanK() {
        IList<Integer> list = makeBasicList();
        
        IList<Integer> topKList = Searcher.topKSort(60, list);
        
        for (int i = 0; i < list.size(); i++) {
            assertEquals(list.get(i), topKList.get(i));
        }
        assertEquals(50, topKList.size());
    }
    
    @Test(timeout=SECOND)
    public void testKandListSizeAreSame() {
        IList<Integer> list = makeBasicList();
        
        IList<Integer> topKList = Searcher.topKSort(50, list);
        
        for (int i = 0; i < list.size(); i++) {
            assertEquals(list.get(i), topKList.get(i));
        }
        assertEquals(50, topKList.size());
    }
    
    @Test(timeout=SECOND)
    public void testTopKSortOf1() {
        IList<Integer> list = makeBasicList();
        
        IList<Integer> topKList = Searcher.topKSort(1, list);
        
        assertEquals(49, topKList.get(0));
        assertEquals(1, topKList.size());
    }
    
    
    @Test(timeout=SECOND)
    public void testInvalidTopKArgument() {
        IList<Integer> list = makeBasicList();
        
        try {
            IList<Integer> topKList = Searcher.topKSort(-1, list);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException ex) {
            // do nothing
        }
    }
    
    @Test(timeout=SECOND)
    public void testInputOrderIsPreservedAfterSort() {
        IList<Integer> inputList = makeBasicList();
        IList<Integer> outputList = makeBasicList();
        
        IList<Integer> topKList = Searcher.topKSort(20, inputList);
        
        for (int i = 0; i < outputList.size(); i++) {
            assertEquals(outputList.get(i), inputList.get(i));
        }
        assertEquals(20, topKList.size());
    }
    
    @Test(timeout=SECOND)
    public void testOutputOrderIsSorted() {
        IList<Integer> inputList = new DoubleLinkedList<>();
        IList<Integer> outputList = new DoubleLinkedList<>();
        
        inputList.add(7);
        inputList.add(5);
        inputList.add(13);
        inputList.add(3);
        inputList.add(6);
        
        outputList.add(5);
        outputList.add(6);
        outputList.add(7);
        outputList.add(13);
        
        IList<Integer> topKList = Searcher.topKSort(4, inputList);
                       
        for (int i = 0; i < outputList.size(); i++) {
            assertEquals(outputList.get(i), topKList.get(i));
        }
    }
    
    @Test(timeout=SECOND)
    public void testTopOneSort() {
        IList<Integer> testList = makeBasicList();
        
        IList<Integer> topKList = Searcher.topKSort(1, testList);
        
        assertEquals(49, topKList.get(0));
        assertEquals(1, topKList.size());
    }
    
    @Test(timeout=SECOND)
    public void testTopKSortOnListOfSameValues() {
        IList<Integer> inputList = new DoubleLinkedList<>();
        for (int i = 0; i < 20; i++) {
            inputList.add(1);
        }
        
        IList<Integer> topKList = Searcher.topKSort(10, inputList);
        
        IList<Integer> outputList = new DoubleLinkedList<>();
        for (int i = 0; i < 10; i++) {
            outputList.add(1);
        }
        
        for (int i = 0; i < outputList.size(); i++) {
            assertEquals(outputList.get(i), topKList.get(i));
        }
        assertEquals(10, topKList.size());

    }
    
    @Test(timeout=SECOND)
    public void testTopKSortWithDuplicateValues() {
        IList<Integer> inputList = new DoubleLinkedList<>();
        IList<Integer> outputList = new DoubleLinkedList<>();
        
        for (int i = 0; i < 3; i++) {
            inputList.add(3);
            outputList.add(3);
        }
        
        for (int i = 0; i < 3; i++) {
            inputList.add(i);
        }
        
        IList<Integer> topKList = Searcher.topKSort(3, inputList);
        
        for (int i = 0; i < outputList.size(); i++) {
            assertEquals(outputList.get(i), topKList.get(i));
        }
        
        assertEquals(3, topKList.size());
    }
}
