package datastructures.sorting;

import misc.BaseTest;
import misc.Searcher;

import org.junit.Test;

import datastructures.concrete.ArrayHeap;
import datastructures.concrete.DoubleLinkedList;
import datastructures.interfaces.IList;
import datastructures.interfaces.IPriorityQueue;

/**
 * See spec for details on what kinds of tests this class should include.
 */
public class TestSortingStress extends BaseTest {
    protected <T extends Comparable<T>> IPriorityQueue<T> makeInstance() {
        return new ArrayHeap<>();
    }
    
    @Test(timeout=10*SECOND) 
    public void testRemoveMany() {
        IPriorityQueue<Integer> testHeap = this.makeInstance();
        for (int i = 0; i < 5000000; i++) {
            testHeap.insert(i);
        }
        
        for (int i = 0; i < 5000000 - 1; i++) {
            testHeap.removeMin();
        }
        
        int ret = testHeap.removeMin();
        
        assertEquals(4999999, ret);
        assertEquals(0, testHeap.size());
    }
    
    @Test(timeout=10*SECOND) 
    public void testInsertMany() {
        IPriorityQueue<Integer> testHeap = this.makeInstance();
        for (int i = 0; i < 5000000; i++) {
            testHeap.insert(i);
        }
        assertEquals(5000000, testHeap.size());
    }  
    
    @Test(timeout=10*SECOND) 
    public void testInsertAndRemoveSimultaneously() {
        IPriorityQueue<Integer> testHeap = this.makeInstance();
        for (int i = 0; i < 5000000; i++) {
            testHeap.insert(i);
            testHeap.removeMin();
        }
        
        assertEquals(0, testHeap.size());
    }
    
    @Test(timeout=10*SECOND) 
    public void testPeakMin() {
        IPriorityQueue<Integer> testHeap = this.makeInstance();
        for (int i = 1; i < 5000001; i++) {
            testHeap.insert(i);
        }
        
        int ret = testHeap.peekMin();
   
        assertEquals(1, ret);
        assertEquals(5000000, testHeap.size());
    }
    
    
    @Test(timeout=10*SECOND)
    public void testTopKManyForBigList() {
        IList<Integer> inputList = new DoubleLinkedList<>();
        IList<Integer> ouputList = new DoubleLinkedList<>();
        
        for (int i = 0; i < 50000; i++) {
            inputList.add(i);
            
            if (i > 24999) {
                ouputList.add(i);
            }
        } 
        
        IList<Integer> topKList = Searcher.topKSort(25000, inputList);
        
        for (int i = 0; i < ouputList.size(); i++) {
            assertEquals(ouputList.get(i), topKList.get(i));
        }
        
        assertEquals(25000, topKList.size());
        
    }
}
