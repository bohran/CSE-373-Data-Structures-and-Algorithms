package datastructures.concrete;
import datastructures.interfaces.IPriorityQueue;
import misc.exceptions.EmptyContainerException;
//import misc.exceptions.NotYetImplementedException;

/**
 * See IPriorityQueue for details on what each method must do.
 */
public class ArrayHeap<T extends Comparable<T>> implements IPriorityQueue<T> {
    // See spec: you must implement a implement a 4-heap.
    private static final int NUM_CHILDREN = 4;

    // You MUST use this field to store the contents of your heap.
    // You may NOT rename this field: we will be inspecting it within
    // our private tests.
    private T[] heap;
    private int heapSize;

    // Feel free to add more fields and constants.

    public ArrayHeap() {
        this.heap = makeArrayOfT(100);
        this.heapSize = 0;
    }

    /**
     * This method will return a new, empty array of the given size
     * that can contain elements of type T.
     *
     * Note that each element in the array will initially be null.
     */
    @SuppressWarnings("unchecked")
    private T[] makeArrayOfT(int size) {
        // This helper method is basically the same one we gave you
        // in ArrayDictionary and ChainedHashDictionary.
        //
        // As before, you do not need to understand how this method
        // works, and should not modify it in any way.
        return (T[]) (new Comparable[size]);
    }

    @Override
    public T removeMin() {
        if (heapSize == 0) {
            throw new EmptyContainerException();
        }
        
        T min = heap[0];
        heap[0] = heap[heapSize - 1];
        heapSize--;
        int current = 0;
        
        while (!isLeaf(current) && heap[current].compareTo(heap[minChild(current)]) > 0) {
            int childToSwap = minChild(current);
            swap(current, childToSwap);  
            current = childToSwap;
        }        
        return min;
    }

    @Override
    public T peekMin() {
        if (heapSize == 0) {
            throw new EmptyContainerException();
        }
        return heap[0];
    }

    @Override
    public void insert(T item) {
        if (item == null) {
            throw new IllegalArgumentException();
        }
        if (heapSize >= heap.length) {
            expandArrayHeap();
        }
        
        heap[heapSize] = item;
        int current = heapSize;
        
        while (current != 0 && heap[current].compareTo(heap[parent(current)]) < 0) {
            swap(current, parent(current));  
            current = parent(current);
        }
        
        heapSize++;
    }

    @Override
    public int size() {
        return this.heapSize;
    }
    
    private int leftMostChild(int parent) {
        return (4 * parent) + 1;
    }
    
    private int parent(int child) {
        int parentIndex = (child - 1) / 4;
        return parentIndex;
    }
    
    private int minChild(int parent) {
        // this function assumes there is at least one child
        int left = leftMostChild(parent);
        int minIndex = left;
        T minValue = heap[left];
        
        for (int i = 1; i <= 3; i++) {
            if (isInHeap(left + i)) {
                if (heap[left + i].compareTo(minValue) < 0) {
                    minValue = heap[left + i];
                    minIndex = left + i;
                }
            }
        }
        return minIndex;
    }
    
    private boolean isLeaf(int index) {
        int left = leftMostChild(index);
        return (left >= heapSize);
    }
    
    private boolean isInHeap(int index) {
        return index < heapSize;
    }
    
    private void swap(int index1, int index2) {
        T temp = heap[index1];
        heap[index1] = heap[index2];
        heap[index2] = temp;
    }
    
    private void expandArrayHeap() {
        T[] newHeap = makeArrayOfT(heap.length * 2);
        for (int i = 0; i < heapSize; i++) {
            newHeap[i] = heap[i];
        }
        heap = newHeap;
    }
 
}
