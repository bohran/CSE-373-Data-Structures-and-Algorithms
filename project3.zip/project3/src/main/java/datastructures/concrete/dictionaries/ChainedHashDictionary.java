package datastructures.concrete.dictionaries;

import datastructures.concrete.KVPair;
import datastructures.interfaces.IDictionary;
import misc.exceptions.NoSuchKeyException;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * See the spec and IDictionary for more details on what each method should do
 */
public class ChainedHashDictionary<K, V> implements IDictionary<K, V> {
    // You may not change or rename this field: we will be inspecting
    // it using our private tests.
    private IDictionary<K, V>[] chains;
    private int size;
    
    // You're encouraged to add extra fields (and helper methods) though!

    public ChainedHashDictionary() {
        this.chains = makeArrayOfChains(10);
        this.size = 0;
    }

    /**
     * This method will return a new, empty array of the given size
     * that can contain IDictionary<K, V> objects.
     *
     * Note that each element in the array will initially be null.
     */
    @SuppressWarnings("unchecked")
    private IDictionary<K, V>[] makeArrayOfChains(int chainSize) {
        // Note: You do not need to modify this method.
        // See ArrayDictionary's makeArrayOfPairs(...) method for
        // more background on why we need this method.
        return (IDictionary<K, V>[]) new IDictionary[chainSize];
    }

    @Override
    public V get(K key) {
        int numIndex = 0;
        if (key != null) {
            int keyHash = Math.abs(key.hashCode());  // since hash code can be negative
            numIndex = keyHash % chains.length;
        }

        IDictionary<K, V> chainEntry = chains[numIndex];
        if (this.containsKey(key)) {
             return chainEntry.get(key);
        } else {
            throw new NoSuchKeyException();
        }
    }

    @Override
    public void put(K key, V value) {
        int numIndex = 0;
        if (key != null) {
            int keyHash = Math.abs(key.hashCode()); // since hash code can be negative
            numIndex = keyHash % chains.length;
        }

        IDictionary<K, V> chainEntry = chains[numIndex];
        
        if (chainEntry != null) {
            // bucket exists in current dictionary
            if (this.size >= this.chains.length) {// check load factor
                // double size of dictionary and copy existing buckets
                IDictionary<K, V>[] savedChains = chains;
                chains = makeArrayOfChains(2 * savedChains.length);
                size = 0;
                // copy current buckets to new dictionary
                for (int i = 0; i < savedChains.length; i++) {
                    if (savedChains[i] != null) {
                        for (KVPair<K, V> entry : savedChains[i]) {
                            this.put(entry.getKey(), entry.getValue());
                        }
                    }
                }
                this.put(key, value);
            } else {
                // insert in current bucket
                if (!chainEntry.containsKey(key)) {
                    size++;
                }
                chainEntry.put(key, value);
            }
        } else {
            // bucket does not exist in current dictionary
            chainEntry = new ArrayDictionary<K, V>();
            chainEntry.put(key, value);
            size++;
            chains[numIndex] = chainEntry;
        }
    }
    
    @Override
    public V remove(K key) {
        int numIndex = 0;
        if (key != null) {
            int keyHash = Math.abs(key.hashCode());  // since hash code can be negative
            numIndex = keyHash % chains.length;
        }
        
        if (chains[numIndex] == null) {
            throw new NoSuchKeyException(); 
        }
        
        IDictionary<K, V> chainEntry = chains[numIndex];
        this.size--;
        return chainEntry.remove(key);
    }

    @Override
    public boolean containsKey(K key) {
        int numIndex = 0;
        if (key != null) {
            int keyHash = Math.abs(key.hashCode());  // since hash code can be negative
            numIndex = keyHash % chains.length;
        }
        
        if (chains[numIndex] == null) {
            return false;
        } else {
            IDictionary<K, V> chainEntry = chains[numIndex];
            return (chainEntry.containsKey(key));            
        }
    }

    @Override
    public int size() {
        return this.size;
    }

    @Override
    public Iterator<KVPair<K, V>> iterator() {
        // Note: you do not need to change this method
        return new ChainedIterator<>(this.chains);
    }

    /**
     * Hints:
     *
     * 1. You should add extra fields to keep track of your iteration
     *    state. You can add as many fields as you want. If it helps,
     *    our reference implementation uses three (including the one we
     *    gave you).
     *
     * 2. Before you try and write code, try designing an algorithm
     *    using pencil and paper and run through a few examples by hand.
     *
     *    We STRONGLY recommend you spend some time doing this before
     *    coding. Getting the invariants correct can be tricky, and
     *    running through your proposed algorithm using pencil and
     *    paper is a good way of helping you iron them out.
     *
     * 3. Think about what exactly your *invariants* are. As a
     *    reminder, an *invariant* is something that must *always* be 
     *    true once the constructor is done setting up the class AND 
     *    must *always* be true both before and after you call any 
     *    method in your class.
     *
     *    Once you've decided, write them down in a comment somewhere to
     *    help you remember.
     *
     *    You may also find it useful to write a helper method that checks
     *    your invariants and throws an exception if they're violated.
     *    You can then call this helper method at the start and end of each
     *    method if you're running into issues while debugging.
     *
     *    (Be sure to delete this method once your iterator is fully working.)
     *
     * Implementation restrictions:
     *
     * 1. You **MAY NOT** create any new data structures. Iterators
     *    are meant to be lightweight and so should not be copying
     *    the data contained in your dictionary to some other data
     *    structure.
     *
     * 2. You **MAY** call the `.iterator()` method on each IDictionary
     *    instance inside your 'chains' array, however.
     */
    private static class ChainedIterator<K, V> implements Iterator<KVPair<K, V>> {
        private IDictionary<K, V>[] chainsPrivate;
        private Iterator<KVPair<K, V>> nextIter;
        private int nextIndex;

        public ChainedIterator(IDictionary<K, V>[] chains) {
            chainsPrivate = chains;
            nextIndex = 0;
            nextIter = null;
            while (nextIndex < chainsPrivate.length && chainsPrivate[nextIndex] == null) {
                nextIndex++;
            }
            if (nextIndex < chainsPrivate.length) {
                nextIter = chainsPrivate[nextIndex].iterator();    
            }
        }

        @Override
        public boolean hasNext() {
            if (nextIter == null) {
                return false;
            } else {
                return nextIter.hasNext();
            }
        }

        @Override
        public KVPair<K, V> next() {
            KVPair<K, V> entry;
            
            if (!this.hasNext()) {
                throw new NoSuchElementException();
            }
            
            entry = nextIter.next();
            
            if (!nextIter.hasNext()) {
                nextIndex++;
                while (nextIndex < chainsPrivate.length && chainsPrivate[nextIndex] == null) {
                    nextIndex++;
                }
                if (nextIndex < chainsPrivate.length) {
                    nextIter = chainsPrivate[nextIndex].iterator();    
                }              
            }
            
            return entry;
        }
    }
}
