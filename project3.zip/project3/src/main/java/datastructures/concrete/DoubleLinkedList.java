package datastructures.concrete;

import datastructures.concrete.DoubleLinkedList.Node;
import datastructures.interfaces.IList;
import misc.exceptions.EmptyContainerException;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class DoubleLinkedList<T> implements IList<T> {

    private Node<T> front;
    private Node<T> back;
    private int size;

    public DoubleLinkedList() {
        this.front = null;
        this.back = null;
        this.size = 0;
    }

    @Override
    public void add(T item) {

        Node<T> newNode = new Node<T>(item);

        if (this.front == null) {
            this.front = newNode;
            this.back = newNode;
        } else {
            this.back.next = newNode;
            newNode.prev = this.back;
            this.back = newNode;
        }
        this.size++;
    }

    @Override
    public T remove() {

        if (this.size == 0) {
            throw new EmptyContainerException();
        }

        T temp = null;

        if (this.size == 1) {
            temp = this.front.data;
            this.back = null;
            this.front = null;
        } else {
            temp = this.back.data;
            this.back = this.back.prev;
            this.back.next = null;
        }
        this.size--;
        return temp;
    }

    @Override
    public T get(int index) {

        if (index < 0 || index >= this.size()) {
            throw new IndexOutOfBoundsException();
        }

        Node<T> current = this.front;
        int counter = 0;
        T data = null;

        while (current != null) {
            if (counter == index) {
                data = current.data;
            }
            counter++;
            current = current.next;
        }
        return data;
    }

    @Override
    public void set(int index, T item) {
        if (index < 0 || index >= this.size()) { 
            throw new IndexOutOfBoundsException();
        }

        Node<T> newNode = new Node<T>(item);

        if (this.size == 1) {
            this.front = newNode;
            this.back = newNode;
        } else if (index == 0) {
            newNode.next = this.front.next;
            this.front.next.prev = newNode;
            this.front = newNode;
        } else if (index == this.size - 1) {

            Node<T> current = back;
            current.prev.next = newNode;
            newNode.prev = current.prev;
            current = null;
        } else {
            int counter = 0;
            Node<T> current = front;
            while (counter != index) {
                current = current.next;
                counter++;
            }

            newNode.next = current.next;
            newNode.prev = current.prev;
            current.next.prev = newNode;
            current.prev.next = newNode;
            current = null;
        }
    }

    @Override
    public void insert(int index, T item) {
        if (index < 0 || index >= this.size() + 1) {
            throw new IndexOutOfBoundsException();
        }

        Node<T> newNode = new Node<T>(item);

        if (this.front == null) {
            this.front = newNode;
            this.back = newNode;
            this.size++;
        } else if (index == 0) {
            this.front.prev = newNode;
            newNode.next = this.front;
            this.front = newNode;
            this.size++;
        } else if (index == this.size) {
            add(item);
        } else if (index < this.size / 2) {
            Node<T> current = front;
            int counter = 0;
            while (counter != index) {
                current = current.next;
                counter++;
            }
            insertMidNodeHelper(newNode, current);
        } else {
            Node<T> current = back;
            int counter = this.size - 1;
            while (counter != index) {
                current = current.prev;
                counter--;
            }
            insertMidNodeHelper(newNode, current);
        }
    }
    
    // Manipulates current, next, and previous node pointers to insert new node and update size
    private void insertMidNodeHelper(Node<T> newNode, Node<T> current) {
        newNode.next = current;
        newNode.prev = current.prev;
        current.prev.next = newNode;
        current.prev = newNode;
        this.size++;
    }
    public T delete(int index) {
        // Make sure index refers to an actual element.
        if (index < 0 || index >= this.size) {
            throw new IndexOutOfBoundsException();
        }

        Node<T> node = this.getNode(index);

        if (this.size() == 1) {
            // Single-element list edge-case. Don't need to worry about anything but removing the element.
            this.front = null;
            this.back = null;
        } else if (index == 0) {
            // Remove the front of the list
            this.front = node.next;
            this.front.prev = null;
        } else if (index == this.size - 1) {
            // Element is at the back of the list
            this.back = node.prev;
            this.back.next = null;
        } else {
            node.prev.next = node.next;
            node.next.prev = node.prev;
        }

        if (this.size() == 1) {
            if (this.front != null) {
                this.back = this.front;
            } else if (this.back != null) {
                this.front = this.back;
            }
        }

        // Updates size and returns data.
        this.size--;
        return node.data;
    }
    
    private Node<T> getNode(int index) {
        // Make sure index refers to an actual element.
        if (index < 0 || index >= this.size()) {
            throw new IndexOutOfBoundsException();
        }

        Node<T> cur;

        // If the index is in the first half of the list, start from the front, going forward.
        // Otherwise, start from the end, going backward.
        if (index < this.size / 2) {
            cur = this.front;
            // Go to the next element index amount of times.
            for (int i = 0; i < index; i++) {
                cur = cur.next;
            }
        } else {
            cur = this.back;
            // Since we're starting from the back, i, the number of times we have to do .prev, will be less than index
            // is. E.g. if the list has 10 elements and we want the 7th, we only need to use .prev 10 - 7 - 1 = 2 times.
            for (int i = this.size - 1; i > index; i--) {
                cur = cur.prev;
            }
        }

        return cur;
    }

    @Override
    public int indexOf(T item) {
        int counter = 0;
        Node<T> current = front;

        while (current != null) {
            if (current.data == item || current.data.equals(item)) {
                return counter;
            }
            current = current.next;
            counter++;
        }
        return -1;
    }

    @Override
    public int size() {
        return this.size;
    }

    @Override
    public boolean contains(T other) {

        Node<T> current = this.front;

        while (current != null) {
            if (current.data == null) {
                if (other == null) {
                    return true;
                }
            } else if (current.data.equals(other)) {
                return true;
            }
            current = current.next;
        }
        return false;
    }

    @Override
    public Iterator<T> iterator() {
        return new DoubleLinkedListIterator<>(this.front);
    }

    public static class Node<E> {
        public final E data;
        public Node<E> prev;
        public Node<E> next;
        public Node(Node<E> prev, E data, Node<E> next) {
            this.data = data;
            this.prev = prev;
            this.next = next;
        }
        public Node(E data) {
            this(null, data, null);
        }
    }

    private static class DoubleLinkedListIterator<T> implements Iterator<T> {
        private Node<T> current;
        public DoubleLinkedListIterator(Node<T> current) {
            this.current = current;
        }
        public boolean hasNext() {
            return current != null;
        }
        public T next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            T nextData = current.data;
            current = current.next;
            return nextData;
        }
    }
}


