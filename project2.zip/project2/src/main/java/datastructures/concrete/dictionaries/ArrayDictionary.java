package datastructures.concrete.dictionaries;

import datastructures.concrete.KVPair;
//import datastructures.concrete.dictionaries.ArrayDictionary.Pair;
import datastructures.interfaces.IDictionary;
import misc.exceptions.NoSuchKeyException;
//import misc.exceptions.NotYetImplementedException;

import java.util.Iterator;

/**
 * TODO: Replace this file with the one you wrote from project 1
 * TODO: Add the missing "iterator()" method
 */
public class ArrayDictionary<K, V> implements IDictionary<K, V> {
    private Pair<K, V>[] pairs;
    private int size;


    public ArrayDictionary() {
        pairs = makeArrayOfPairs(10);
    }

    @SuppressWarnings("unchecked")
    private Pair<K, V>[] makeArrayOfPairs(int arraySize) {
        return (Pair<K, V>[]) (new Pair[arraySize]);
    }

    @Override
    public V get(K key) {
        if (!containsKey(key)) {
            throw new NoSuchKeyException();
        }
        V value = null;
        int numIndex = keyIndexHelper(key);
        if (numIndex != -1) {
            value = this.pairs[numIndex].value;
        } 
        return value;        
    }    

    @Override
    public void put(K key, V value) {
            int numIndex = keyIndexHelper(key);
            if (numIndex != -1) {
                this.pairs[numIndex].value = value;
            } else if (size >= this.pairs.length) {
                Pair<K, V>[] doubleArray = makeArrayOfPairs(2 * this.pairs.length);
                for (int i = 0; i < this.pairs.length; i++) {
                    doubleArray[i] = this.pairs[i];
                }
                doubleArray[size] = new Pair<>(key, value);
                this.pairs = doubleArray;
                size++;
            } else {
                this.pairs[size] = new Pair<>(key, value);
                size++;
            }    
      }

    @Override
    public V remove(K key) {
        if (!containsKey(key)) {
            throw new NoSuchKeyException();
        }
        int numIndex = keyIndexHelper(key);
        Pair<K, V> removedPair = this.pairs[numIndex];
        this.pairs[numIndex] = this.pairs[size - 1];
        pairs[size - 1] = null;
        this.size--;
        return removedPair.value;
    }
    
    private int keyIndexHelper(K key) { 
        for (int i = 0; i < size; i++) {  
            if (pairs[i].key == key || pairs[i].key.equals(key)) { 
               return i; 
            }
        }
        return -1;
    }

    @Override
    public boolean containsKey(K key) {
        return keyIndexHelper(key) != -1;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public Iterator<KVPair<K, V>> iterator() {
        return new ArrayDictionaryIterator<>(this.pairs, this.size); 
    }

    private static class Pair<K, V> {
        public K key;
        public V value;

        // You may add constructors and methods to this class as necessary.
        public Pair(K key, V value) {
            this.key = key;
            this.value = value;
        }

        @Override
        public String toString() {
            return this.key + "=" + this.value;
        }
    }

private static class ArrayDictionaryIterator<K, V> implements Iterator<KVPair<K, V>> {
    private Pair<K, V>[] array;
    private int size;
    private int nextIndex;
    
    public ArrayDictionaryIterator(Pair<K, V>[] array, int size) {
        this.array = array;
        this.size = size;
        this.nextIndex = 0;
    }
    
    @Override
    public boolean hasNext() {
        return this.nextIndex < this.size;
    }

    @Override
    public KVPair<K, V> next() {
        if (!this.hasNext()) {
            throw new NoSuchKeyException();
        }
        Pair<K, V> pair = this.array[this.nextIndex];
        this.nextIndex +=1; 
        KVPair<K, V> returnType = new KVPair<K, V>(pair.key, pair.value); 
        return returnType; 
    }
}
}