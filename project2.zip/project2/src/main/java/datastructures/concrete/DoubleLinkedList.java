package datastructures.concrete;

import datastructures.interfaces.IList;
import misc.exceptions.NotYetImplementedException;

import java.util.Iterator;

/**
 * TODO: Replace this file with the one you wrote from project 1
 */
public class DoubleLinkedList<T> implements IList<T> {
    @Override
    public void add(T item) {
        throw new NotYetImplementedException();
    }

    @Override
    public T remove() {
        throw new NotYetImplementedException();
    }

    @Override
    public T get(int index) {
        throw new NotYetImplementedException();
    }

    @Override
    public void set(int index, T item) {
        throw new NotYetImplementedException();
    }

    @Override
    public void insert(int index, T item) {
        throw new NotYetImplementedException();
    }

    @Override
    public T delete(int index) {
        throw new NotYetImplementedException();
    }

    @Override
    public int indexOf(T item) {
        throw new NotYetImplementedException();
    }

    @Override
    public int size() {
        throw new NotYetImplementedException();
    }

    @Override
    public boolean contains(T other) {
        throw new NotYetImplementedException();
    }

    @Override
    public Iterator<T> iterator() {
        throw new NotYetImplementedException();
    }
}
